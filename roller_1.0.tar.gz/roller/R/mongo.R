# contains wrapper functions to conveniently query mongodb from R

affogato.db.connect = function(hostname = "impedimenta") {
    library(rmongodb)
    valid.hostnames = c("impedimenta", "vitalstatistix",
                        "amazon.master")
    if ( ! hostname %in% valid.hostnames )
        stop(sprintf("Error: valid hostnames are:\n%s", 
                     paste(valid.hostnames, collapse = "\n")))
    h = system("hostname", intern = TRUE)
    if ( hostname == "amazon.master" )
        hostname = "23.23.153.188"
    else  {
        # if we're on a server, just use the server name
        if ( (h != "getafix") && (h != "vitalstatistix") ) {
            # ping the host and get its address
            cmd.str = sprintf("ping -c 1 %s | head -1 | sed 's:^.*(::' | sed 's:).*$::'", hostname)
            hostname = system(cmd.str, intern = TRUE)
        }
    }
    db.name = mongo.create(host = hostname, 
                           username = "cmap_user", 
                           password = "l1000", 
                           db = "affogato")
    return(db.name)
}

mongo.to.vector = function(db, collection = "affogato.signature",
                           query = mongo.bson.empty(),
                           sort.output = mongo.bson.empty(),
                           field = "sig_id",
                           limit = 0L,
                           skip = 0L,
                           options = 0L) {
    # takes a query and a field (a character vector of length 1) as input
    # returns the values of the specified field in the entries matching the query
    # returns an error if the field has values that are more than a single element
    
    # check that the field is valid
    if ( length(field) != 1 )
        stop("Invalid field specified; must give exactly 1 field to return")
    # make the list saying which field to retrieve
    eval(parse(text = sprintf('field.list = list(%s = TRUE, "_id" = FALSE)', field))) 
    n = mongo.count(db, collection, query)
    if ( limit )
        n = min(limit, mongo.count(db, collection, query))
    else
        n = mongo.count(db, collection, query)
    if ( ! n )
        stop("No matching queries were found")
    query.vals = rep(0, n)
    c = mongo.find(db, collection, query, sort.output, field.list, limit, skip, options)
    for ( i in 1:n ) {
        mongo.cursor.next(c)
        tmp = mongo.bson.to.list(mongo.cursor.value(c))
        # make sure the query behaves well; if it does, append it
        if ( is.list(tmp) )
            stop(sprintf("A list, instead of a vector of length 1, was returned for entry %d of query", i))
        else {
            if ( length(tmp) != 1 ) {
                stop(sprintf("A vector of length %d was returned for entry %d of the query", length(tmp), i))
            }
            else {
                query.vals[i] = tmp
            }
        }
    }
    return(query.vals)
}

mongo.to.list = function(db, collection = "affogato.signature",
                         query = mongo.bson.empty(), 
                         sort.output = mongo.bson.empty(),
                         fields = c("sig_id", 
                                    "pert_id",
                                    "pert_desc",
                                    "cell_id",
                                    "pert_type",
                                    "pert_time", 
                                    "pert_time_unit", 
                                    "pert_dose", 
                                    "pert_dose_unit",
                                    "is_gold", 
                                    "distil_cc_q75", 
                                    "distil_ss", 
                                    "pct_self_rank_q25"),
                         limit = 0L,
                         skip = 0L,
                         options = 0L,
                         show._id = FALSE) {
    # turn the vector into a list of fields for the mongo query
    field.list = vector("list", length(fields))
    names(field.list) = fields
    field.list = lapply(field.list, function(x) x = TRUE)
    if ( ! show._id )
        field.list[["_id"]] = FALSE
    if ( limit )
        n = min(limit, mongo.count(db, collection, query))
    else
        n = mongo.count(db, collection, query)
    if ( ! n )
        stop("No matching queries were found")
    c = mongo.find(db, collection, query, 
                   sort.output, field.list, limit, skip, options)
    L = vector(mode = "list", length = n)
    for ( i in 1:n ) {
        mongo.cursor.next(c)
        tmp = mongo.bson.to.list(mongo.cursor.value(c))
        if ( is.character(tmp) )
            L[[i]] = as.list(tmp)
        else
            L[[i]] = tmp
    }
    return(L)
}

mongo.to.data.frame = function(db, collection = "affogato.signature",
                               query = mongo.bson.empty(), 
                               sort.output = mongo.bson.empty(),
                               fields = c("sig_id",
                                          "pert_id",
                                          "pert_desc",
                                          "cell_id",
                                          "pert_type",
                                          "pert_time",
                                          "pert_time_unit",
                                          "pert_dose",
                                          "pert_dose_unit",
                                          "is_gold",
                                          "distil_cc_q75",
                                          "distil_ss",
                                          "pct_self_rank_q25"),
                               limit = 0L,
                               skip = 0L,
                               options = 0L,
                               show._id = FALSE) {
    # call mongo.to.list
    L = mongo.to.list(db, collection, query, sort.output, fields, 
                      limit, skip, options, show._id)
    # make vectors out of all the fields, then join them in a data frame
    # much faster this way
    for ( field in fields ) {
        eval(parse(text = sprintf("this.field = lapply(L, function(x) x$%s)", field)))
        is.scalar = all(unlist(lapply(this.field, function(x) length(x))) == 1)
        if ( ! is.scalar )
            stop(sprintf("The field %s has non-scalar entries; use mongo.to.vector to handle this", field))
        eval(parse(text = sprintf("%s = unlist(this.field)", field)))
    }
    eval(parse(text = sprintf("ds = data.frame(%s)", 
                              paste(paste(fields, fields, sep = "="), collapse = ", "))))
    return(ds)
}
