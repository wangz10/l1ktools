dev.analysis = function(csv.path, out.path) {
	library(brtk)
	library(gdata, warn.conflicts = FALSE, quietly = TRUE)
	out.path = sub("/$", "", out.path)
	csv.name = sub("/.*/", "", csv.path)
	csv.name = sub("\\..*$", "", csv.name)
    # read in the data set
	ds = read.xls(csv.path)
	# check that the data set has correct number of columns
	stopifnot(dim(ds)[2] == 502)
	# extract the wells conditions
	wells = as.character(ds[,1])
	condition = as.factor(ds[,2])
	# extract the matrix and invariant set
	mat = ds[,-1:-2]
	invset = mat[,1:10]
	# output samples with at least one NaN
	idx.nan = is.nan(as.matrix(mat))
	nan.by.well = apply(idx.nan, 1, any)
	nan.wells = wells[nan.by.well]
	if (length(idx.nan)) {
		for (well in nan.wells) {
			# file to write the NaN wells to
			nan.file = paste(out.path, sprintf("%s_nan_wells.txt", csv.name), 
					sep = "/")
			well.idx = wells == well
			v = names(mat)[idx.nan[well.idx,]]
			cat(sprintf("Well %s has NaN values for the following analytes:\n", well),
					file = nan.file, append = TRUE)
			cat(paste(sub("Analyte.", "", v), collapse = "\n"),
					file = nan.file, append = TRUE)
			cat("\n", file = nan.file, append = TRUE)
		}
	}		
	# plot invariant set expression by condition
	invset.by.cond = t(simplify2array(by(invset, condition,
							function(x) sapply(x, median, na.rm = TRUE))))
	invset.plot.path = paste(out.path, sprintf("%s_invset.png", csv.name), sep = "/")
	png(filename = invset.plot.path, width = 800, height = 800)
	matplot(1:10, t(invset.by.cond), type = "l", lty = 1:5, col = 1:6,
			lwd = 2, xaxp = c(1,10,9),
			xlab = "Invariant Level", ylab = "Median Expression",
	main = "Invariant Set Expression by Treatment Group")
	legend(x = "topleft", legend = rownames(invset.by.cond), 
			lwd = 2, lty = 1:5, col = 1:6, cex = 1.5)
	dev.off()
	# plot gene expression quantiles by condition
	gex.qntl = t(apply(mat, 1, 
					function(x) quantile(x, c(0.01, 0.25, 0.5, 0.75, 0.99), na.rm = TRUE)))
	qntl.by.cond = t(simplify2array(by(gex.qntl, condition, 
						function(x) sapply(x, median, na.rm = TRUE))))
	ncond = length(levels(condition))
	xpts = matrix(sort(rep(1:ncond,5)),5,ncond)
	qtl.plot.path = paste(out.path, sprintf("%s_quantiles.png", csv.name), sep = "/")
	png(filename = qtl.plot.path, width = 800, height = 800)
	matplot(xpts, t(qntl.by.cond), type = "p", pch = 1:5, col = 1:6, cex = 1.5,
		xaxp = c(1,ncond,ncond-1),
		xlab = "Treatment Group", ylab = "Gene Expression",
		main = "Gene Expression Quantiles by Treatment Group")
	legend(x = "topleft", legend = rownames(qntl.by.cond), 
			pch = 1:5, col = 1:6, cex = 1.5)
	dev.off()
	# make table
	max.inv = apply(invset.by.cond, 1, max)
	min.inv = apply(invset.by.cond, 1, min)
	span = max.inv - min.inv
	range = max.inv / min.inv
    
	compute.cv = function(mat, condition) {
	    median.by.cond = t(simplify2array(by(mat, condition,
	                                         function(x) sapply(x, median, na.rm = TRUE))))
	    mad.by.cond = t(simplify2array(by(mat, condition,
	                                      function(x) sapply(x, mad, na.rm = TRUE))))
	    cv.by.cond = (mad.by.cond) / median.by.cond
	    cv.by.cond = apply(cv.by.cond, 1, median, na.rm = TRUE)
	    return(cv.by.cond)
	}
    
	cv.by.cond = compute.cv(mat, condition)
	tbl = rbind(span, range, cv.by.cond, t(qntl.by.cond), t(invset.by.cond))
	rownames(tbl) = c("Span", "Range", "CV", "q1", "q25", "q50", "q75", "q99", 
			paste("Analyte", 1:10, sep = "_"))
	tbl.path = paste(out.path, sprintf("%s_dev_tbl.txt", csv.name), sep = "/")
	mktbl(tbl, tbl.path)
}
