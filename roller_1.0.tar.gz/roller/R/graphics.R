density.heatmap = function(x, 
                           y = NULL, 
                           grid.size = 100, 
                           nlevels = 20, 
                           xlim = NULL, 
                           ylim = NULL, 
                           kernel.bw = NULL, 
                           ...) {
    # make a density heatmap given columns of data x and y or matrix with 2 cols
    if ( is.null(y) ) {
        y = x[,2]
        x = x[,1]
    }
    else {
        if ( length(x) != length(y) )
            stop("The input vectors must be the same length")
    }
    # get the grid limits
    if ( is.null(xlim) ) {
        xlim = range(x, finite = TRUE)
    }
    else {
        if ( length(xlim) != 2 )
            stop("xlim must be null or be a vector of length 2")
    }
    if ( is.null(ylim) ) {
        ylim = range(y, finite = TRUE)
    }
    else {
        if ( length(ylim) != 2 )
            stop("ylim must be null or be a vector of length 2")
    }
    lims = c(xlim, ylim)
    if ( is.null(kernel.bw) )
        # call kde2d and have it choose the kernel itself
        L = kde2d(x, y, n = grid.size, lims = lims)
    else
        # give it the bandwidths you want
        L = kde2d(x, y, n = grid.size, lims = lims, h = kernel.bw)
    filled.contour(L$x, L$y, L$z, color.palette = redblu.colors, nlevels = nlevels, xlim = xlim, ylim = ylim, ...)	
}

marker.selection = function(x, l, n = 50, convert.to.gene.symbol = TRUE, ...) {
    library(gplots)
    # takes 2 classes and phenotype labels, performs marker selection
    l = as.character(l)
    srt.L = sort.int(l, index.return = TRUE)
    l.l = unique(srt.L$x)
    N = cbind(sum(l == l.l[1]), sum(l == l.l[2]))
    x.1 = x[,l == l.l[1]]
    x.2 = x[,l == l.l[2]]
    x.bar = cbind(apply(x.1, 1, mean), apply(x.2, 1, mean))
    s.hat.2 = (1 / (sum(N) - 2)) *  (apply((x.1 - x.bar[,1]) ^ 2, 1, sum) + 
                                         apply((x.2 - x.bar[,2]) ^ 2, 1, sum))
    se = sqrt(s.hat.2) * sqrt((1 / N[1]) + (1 / N[2]))
    t = apply(x.bar, 1, diff) / se
    t.srt = sort(t, decreasing = TRUE)
    g = length(t.srt)
    up = names(t.srt)[1:n]
    down = names(t.srt)[(g - n + 1):g]
    x.diff = x[c(up, down),srt.L$ix]
    if ( convert.to.gene.symbol )
        rownames(x.diff) = ps2genesym(rownames(x.diff))
    heatmap.2(x.diff, Rowv = FALSE, Colv = FALSE, dendrogram = "none",
              trace = "none", scale = "row",
              labRow = rownames(x.diff), labCol = srt.L$x,
              ColSideColors = as.character(as.integer(as.factor(srt.L$x)) + 2),
              col = redblu.colors(12), key = TRUE, ...)
    legend("left", legend = l.l, fill = 3:4) 
    if ( convert.to.gene.symbol ) {
        up.list = ps2genesym(up)
        down.list = ps2genesym(down)
    }
    else {
        up.list = up
        down.list = down
    }
    out.list = list(up.list = up.list, down.list = down.list)
    return(out.list)
}

plot.labels <- function(dsname,dsdim,date=FALSE,side=3) {
  if(date){
    lbl=paste(dsname," [",dsdim[1],'x',dsdim[2],'] ',Sys.time(),sep='')
  } else{
    lbl=paste(dsname," [",dsdim[1],'x',dsdim[2],']',sep='')
  }
  mtext(lbl,side)
}
