# Contains functions to convert probe sets to gene symbols and vice versa
# Same as the matlab functions ps2genesym, genesym2ps
# 

ps2genesym = function(ps, 
                      chip.file = "/xchip/cogs/data/vdb/chip/affx.chip") {
    chip = read.table(chip.file, header = TRUE, sep = "\t", quote = NULL)
    if ( length(ps) == 1 && grepl(".grp$", ps) )
        ps = parse.grp(ps)
    # check that the probe id's are unique
    if ( length(chip$pr_id) != length(unique(chip$pr_id)) )
        stop(sprintf("The pr_id values for chip %s are not unique", chip.file))
    # get the mappings from probe sets to genes; simple because probes are unique
    pr.gene.symbol = chip$pr_gene_symbol
    names(pr.gene.symbol) = chip$pr_id
    gsym = pr.gene.symbol[ps]
    names(gsym) = NULL
    return(gsym)
}

genesym2ps = function(genesym, landmarks.only = FALSE,
                      chip.file = "/xchip/cogs/data/vdb/chip/affx.chip") {
    chip = read.table(chip.file, header = TRUE, sep = "\t", quote = NULL)
    if ( length(genesym) == 1 && grepl(".grp$", genesym) )
        genesym = parse.grp(genesym)
    # construct a list mapping the unique gene symbols in the vector to probe id's
    uniq.genesym = sort(unique(genesym))
    # if landmarks.only is true, check that all the genes have a landmark probe
    if ( landmarks.only ) {
        no.lm = uniq.genesym[!is.landmark(uniq.genesym, isgene = TRUE)]
        if ( length(no.lm) )
            stop(sprintf("The following genes have no landmark probes:\n%s", 
                         paste(no.lm, collapse = "\n")))
    }
    L = list()
    for ( g in uniq.genesym ) {
        x = subset(chip, pr_gene_symbol == g,
                   select = "pr_id")$pr_id
        if ( landmarks.only )
            x = x[is.landmark(x)]
        L[[g]] = x
    }
    # now assign actual elements based on the master list
    probe.sets = L[genesym]
    names(probe.sets) = NULL
    # if all the mappings are 1:1, make it into a character vector
    if ( all(unlist(lapply(probe.sets, length)) == 1) )
        probe.sets = unlist(probe.sets)	
    return(probe.sets)
}

is.landmark = function(g, pool = "eps", isgene = FALSE,
                       lm.probes = "/xchip/cogs/data/vdb/spaces/lm_probes.gmx",
                       lm.symbols = "/xchip/cogs/data/vdb/spaces/lm_symbols.gmx") {
    if ( ! isgene ) {
        probes = parse.gmx(lm.probes)
        values = probes[[pool]]$entry
    }
    else {
        genes = parse.gmx(lm.symbols)
        values = genes[[pool]]$entry
    }
    islm = g %in% values
    names(islm) = g
    return(islm)
}

trcn2genesym = function(trcns) {
    read.delim("/xchip/cogs/peyton/trcngene.txt")
    genenames = NULL
    for (i in 1:length(trcns)) {
        index = grep(trcns[i], table[,1])
        genenames = c(genenames, as.character(table[index,2]))
    }
    return(genenames)
}
