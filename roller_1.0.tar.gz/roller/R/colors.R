# Contains code to set the color palette to one of Rajiv's schemes
# Default is "Motley 20"; looks prettier than R's colors

set.palette = function(color.schemes = "/xchip/cogs/data/vdb/color/color_schemes.gmt", 
                       palette.file = "/xchip/cogs/data/vdb/color/palette.txt",
                       palette.choice = "motley20") {
    p = read.table(palette.file, sep = "\t", header = TRUE, comment.char = "")
    s = parse.gmt(color.schemes)
    if ( ! palette.choice %in% names(s) )
        stop(sprintf("Invalid palette choice. Available options are\n%s", 
                     paste(names(s), collapse = "\n")))
    rownames(p) = p$color
    p$color = NULL
    palette(p[s[[palette.choice]]$entry,"hex_code"])
}

redblu.colors = function(n) {
    library(colorspace)
    library(RColorBrewer)
    if ( n <= 11) {
        c = rev(brewer.pal(n, "RdBu"))
        return(c)
    }
    else {
        c = rev(brewer.pal(11, "RdBu"))
        rgb.colors = hex2RGB(c)@coords
        interp.rgb.colors = apply(rgb.colors, 2, function(x) approx(x, n = n)$y)
        return(rgb(	r = interp.rgb.colors[,"R"],
                    g = interp.rgb.colors[,"G"],
                    b = interp.rgb.colors[,"B"],
                    maxColorValue = 1))
    }
}

