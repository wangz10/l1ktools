# contains math functions that R is slow / bad it

fast.cor = function(X, Y = NULL, method = "pearson") {
    if ( !(method %in% c("pearson", "spearman")) )
        stop("Allowed methods are pearson and spearman")
    if ( method == "spearman" )
        X = apply(X, 2, rank, ties.method = "average")
    X.z = scale(X)
    if ( is.null(Y) ) {
        n = dim(X)[1]
        Y.z = X.z
    }
    else {
        if ( dim(X)[1] != dim(Y)[1] )
            stop("Input matrices must have same number of rows")
        else
            n = dim(X)[1]
        if ( method == "spearman" )
            Y = apply(Y, 2, rank, ties.method = "average")
        Y.z = scale(Y)
    }
    rho = (t(X.z) %*% Y.z) / (n - 1)
    return(rho)
}

circshift = function(x, n) {
    L = length(x)
    shift.size = -n %% L
    idx = c((shift.size + 1):L, (1:shift.size))
    return(x[idx])	
}

mutual.inf.v2 <- function(x, y, n.grid=25, delta = c(bcv(x), bcv(y))) {
	
	# For definitions of mutual information and the universal metric (NMI) see the
	# definition of "Mutual Information" in wikipedia and Thomas and Cover's book
	
	kde2d.xy <- kde2d(x, y, n = n.grid, h = delta)
	FXY <- kde2d.xy$z + .Machine$double.eps
	dx <- kde2d.xy$x[2] - kde2d.xy$x[1]
	dy <- kde2d.xy$y[2] - kde2d.xy$y[1]
	PXY <- FXY/(sum(FXY)*dx*dy)
	PX <- rowSums(PXY)*dy
	PY <- colSums(PXY)*dx
	HXY <- -sum(PXY * log(PXY))*dx*dy
	HX <- -sum(PX * log(PX))*dx
	HY <- -sum(PY * log(PY))*dy
	
	PX <- matrix(PX, nrow=n.grid, ncol=n.grid)
	PY <- matrix(PY, byrow = TRUE, nrow=n.grid, ncol=n.grid)
	
	MI <- sum(PXY * log(PXY/(PX*PY)))*dx*dy
	SMI <- sign(cor(x, y)) * MI
	
	NMI <- sign(cor(x, y)) * ((HX + HY)/HXY - 1)  # use Pearson correlation the get the sign (directionality)
	
	return(list(MI=MI, SMI=SMI, HXY=HXY, HX=HX, HY=HY, NMI=NMI))
}

library(misc3d)

cond.mutual.inf <- function(x, y, z, n.grid=25, delta = 0.25*c(bcv(x), bcv(y), bcv(z))) {
	
	# For definitions of conditional mutual information see the
	# definition of "Conditional Mutual Information" in Wikipedia
	# I(X, Y | X) = H(X, Z) + H(Y, Z) - H(X, Y, Z) - H(Z)
	
	kde3d.xyz <- kde3d(x=x, y=y, z=z, h=delta, n = n.grid)
	X <- kde3d.xyz$x
	Y <- kde3d.xyz$y
	Z <- kde3d.xyz$z
	PXYZ <- kde3d.xyz$d + .Machine$double.eps
	
	# get grid spacing
	dx <- X[2] - X[1]
	dy <- Y[2] - Y[1]
	dz <- Z[2] - Z[1]
	
	# normalize density and calculate marginal densities and entropies
	PXYZ <- PXYZ/(sum(PXYZ)*dx*dy*dz)
	PXZ <- colSums(aperm(PXYZ, c(2,1,3)))*dy
	PYZ <- colSums(PXYZ)*dx
	PZ <- rowSums(aperm(PXYZ, c(3,1,2)))*dx*dy
	PXY <- colSums(aperm(PXYZ, c(3,1,2)))*dz
	PX <- rowSums(PXYZ)*dy*dz
	PY <- rowSums(aperm(PXYZ, c(2,1,3)))*dx*dz
	
	HXYZ <- - sum(PXYZ * log(PXYZ))*dx*dy*dz
	HXZ <- - sum(PXZ * log(PXZ))*dx*dz
	HYZ <- - sum(PYZ * log(PYZ))*dy*dz
	HZ <-  - sum(PZ * log(PZ))*dz
	HXY <- - sum(PXY * log(PXY))*dx*dy
	HX <-  - sum(PX * log(PX))*dx
	HY <-  - sum(PY * log(PY))*dy
	
	CMI <- HXZ + HYZ - HXYZ - HZ
	MI <- HX + HY - HXY
	
	return(list(CMI=CMI, MI=MI, HXY=HXY, HXYZ=HXYZ))
}
