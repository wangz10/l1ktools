# Analysis Tools for L1000, etc. that don't fit into another category

maxcliques <- function(bdata, thresh=.2, rankper=.05) {
  
  # with PERT IDs
  bdatamat2 = bdata@mat
  colnames(bdatamat2) = bdata@cdesc[,"pert_id"]
  corrmat = fast.cor(bdatamat2, method="spearman")
  diag(corrmat) = 0
  
  # with PERT DESCS
  bdatamat3 = bdata@mat
  colnames(bdatamat3) = bdata@cdesc[,"pert_desc"]
  corrmat2 = fast.cor(bdatamat3, method="spearman")
  diag(corrmat2) = 0

  # see which edges reach pos or neg correlation thresholds
  adjcorrmat = ifelse(corrmat > thresh,1,0) 
  adjcorrmatneg = ifelse(corrmat < -thresh,1,0)

  # see which edges reach rank thresholds
  rankmat = apply(-corrmat2, 2, rank)
  adjrankmata = ifelse(rankmat<ceiling(rankper*max(rankmat)),1,0) 
  adjrankmataneg = ifelse(rankmat>floor((1-rankper)*max(rankmat)),1,0) 

  # make adjacency matrix requiring both rank and correlation
  adjmata = ifelse((adjcorrmat==1 & adjrankmata==1), 1, 0)
  adjmata = ifelse((adjcorrmatneg==1 & adjrankmataneg==1), -1, adjmata)
  
  # make graph object
  corrgrapha = graph.adjacency(adjmata, mode="max", diag=FALSE, weighted=TRUE)
  if (length(V(corrgrapha))<1) {
    print("No edges to make a graph :( ")
    return(NULL);
  }

  # set colors for pos and negative correlation
  E(corrgrapha)$color = ifelse(E(corrgrapha)$weight==1, "black", "red")

  ## ctlempty = grep('ctl_untrt', bdata@cdesc[,"pert_type"])
  ## ctlvector = grep('ctl_vector', bdata@cdesc[,"pert_type"])
  ## ctlindex = c(ctlempty,ctlvector)
  ## sampindex = seq(1,ncol(bdata@mat))[-ctlindex]
  ## tgenes = unique(bdata@cdesc[,"pert_desc"][sampindex])
  tgenes = unique(bdata@cdesc[,"pert_desc"])
  for (i in 1:length(tgenes)) {
    genename = tgenes[i]
    index = which(bdata@cdesc[,"pert_desc"]==genename)
    trcns = bdata@cdesc[,"pert_id"][index]
    V(corrgrapha)[as.character(trcns)]$gene=as.character(genename)
  }

  maxcliques = matrix(0,nrow=length(tgenes),ncol=1, dimnames=list(tgenes,c("5per")))

# get subgraph 
  for (i in 1:(length(tgenes))) {
    genename = tgenes[i]
    suba <-  subgraph(corrgrapha, which(V(corrgrapha)$gene==genename)-1)
    maxcliques[i,1] = length(largest.cliques(suba)[[1]])
  }

  return(maxcliques)
  
}

